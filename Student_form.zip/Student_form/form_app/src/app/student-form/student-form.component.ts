import { Component } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';

@Component({
  selector: 'app-student-form',
  standalone: true,
  imports: [CommonModule, FormsModule],
  templateUrl: './student-form.component.html',
  styleUrls: ['./student-form.component.css']
})
export class StudentFormComponent {
  studentName: string = '';
  submitted: boolean = false;
  students: string[] = [];
  studentRoll: number | null = null;


  submitForm() {
  const trimmedName = this.studentName.trim();

  if (
    trimmedName.length > 3 &&
    this.studentRoll !== null &&
    this.studentRoll >= 0  
  ) {
    this.students.push(`${this.studentRoll} - ${trimmedName}`);
    this.submitted = true;

    this.studentName = '';
    this.studentRoll = null;

    setTimeout(() => this.submitted = false, 2000);

  }
}

}

