import { Component } from '@angular/core';
import { RouterOutlet } from '@angular/router';
import { StudentFormComponent } from './student-form/student-form.component'; // ✅ Correct path

@Component({
  selector: 'app-root',
  standalone: true,
  imports: [RouterOutlet, StudentFormComponent], 
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent {
  title = 'form-app';
}
